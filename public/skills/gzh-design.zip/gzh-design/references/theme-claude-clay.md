# 公众号排版组件库 —— Claude 陶土

> **使用说明**：本组件库为「Claude 陶土」主题，所有组件使用**内联样式**，可直接复制粘贴到微信公众号编辑器。
>
> **设计风格**：参照 Claude 界面的温暖克制气质。米白底 + 燕麦色卡片 + 陶土橙点睛；标题用衬线体，正文用系统无衬线；章节以 ✻ 星芒符号引出，分隔靠细线和留白，不用重阴影和渐变。适合 AI / 编程实践、技术随笔、读书笔记、观点复盘。
>
> **公众号平台限制须知**：
> - ❌ 不支持 `<style>`/`<script>`、CSS class/id、`position:fixed/absolute`、`float`、`@media`/`@keyframes`、`display:grid`
> - ✅ 支持内联 `style`、`display:flex`（有限）、`border-radius`、`<section>/<p>/<span>/<strong>/<img>/<h3>` 等基础标签
>
> **WeChat 兼容铁律**：
> - 装饰性空元素（细分割线、END 短线）内部必须放 `<span leaf=""><br></span>` 占位
> - 不要把 `font-size`/`border-bottom` 打在 `<strong>` 上；同一个 `<p>` 只用一个字号
> - 全主题只用纯色背景，不用渐变（避免 `darkmode-no-gradient` 检测）
> - 结构化区域没有内容时整块删掉
> - **暗色模式**：微信会按亮度重算颜色，米白 / 燕麦 / 白三层底色在暗色下不保证还能分出层次；图片里的白底和文字不会跟着变。发布前在手机暗色模式下看一遍，重点查浅灰文字、卡片边界、白底图片。数据图用白底出图，和页面融为一体

---

## 设计变量速查表

```
主色（陶土橙）：   #D97757（只用于竖条、圆点、细边等装饰，不用于文字：米白底仅 2.96:1）
主色文字：         #A34F36（所有橙色文字：章节标签、编号、锚点加粗、标签字；米白 5.35:1 / 燕麦 4.85:1 / 标签底 4.71:1）
主色浅：           #EBC7B5（下划线 / 细边）
主色极浅：         #F7E8E0（标签底）
页面底：           不设背景（公众号页面本身是白色；全局容器加米白底会在手机上变成白页里一块米黄方框，2026-10-21 实测）
卡片底（燕麦）：   #F0EEE6
细线色：           #E3DFD3
标题色（墨黑）：   #141413
正文色：           #3D3D3A
辅助文字色：       #6B6A63（出处、说明、旁注；米白 5.15:1 / 燕麦 4.67:1）
正文字号：         15px
行高：             1.85
字间距：           0.4px
最大宽度：         677px
内容区边距：       0 12px
```

正文字体栈：`-apple-system,BlinkMacSystemFont,'PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif`

标题字体栈（衬线，属可选增强：iOS 有宋体；多数安卓机没有中文衬线，会回退成系统黑体，此时靠字号、字重和留白维持层级，验收以回退后的效果为准）：`'Songti SC','STSong','Noto Serif SC',Georgia,serif`

---

## 组件 1 全局容器

```html
<section style="max-width:677px;margin:0 auto;font-family:-apple-system,BlinkMacSystemFont,'PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif;color:#3D3D3A;line-height:1.85;letter-spacing:0.4px;padding:8px 0 24px;overflow-x:hidden;">

  <!-- 所有组件放在这里 -->

</section>
```

---

## 组件 2 开头引言卡（燕麦底 + 陶土左竖条 + 衬线金句）

> 金句从文章核心判断提炼，不复述外标题；署名按实际出处，不知道就删掉整行。

```html
<section style="margin:16px 12px 32px;background:#F0EEE6;border-left:3px solid #D97757;border-radius:0 10px 10px 0;padding:20px 22px;">
  <p style="font-size:13px;color:#D97757;margin:0 0 10px;letter-spacing:2px;">
    <span leaf="">✻</span>
  </p>
  <p style="font-family:'Songti SC','STSong','Noto Serif SC',Georgia,serif;font-size:17px;font-weight:700;color:#141413;margin:0;line-height:1.75;">
    <span leaf="">{{金句}}</span>
  </p>
  <p style="text-align:right;font-size:12px;color:#6B6A63;margin:12px 0 0;">
    <span leaf="">—— {{出处，未知则删整行}}</span>
  </p>
</section>
```

---

## 组件 3 本文看点（竖排目录）

> 3 个及以上章节时生成，展示精选 3 个看点。

```html
<section style="margin:0 12px 36px;">
  <p style="font-size:12px;color:#6B6A63;margin:0 0 12px;letter-spacing:2px;">
    <span leaf="">本文看点</span>
  </p>
  <p style="font-size:14px;color:#141413;margin:0;padding:10px 0;border-top:1px solid #E3DFD3;">
    <span style="color:#A34F36;font-weight:700;"><span leaf="">01　</span></span><span leaf="">{{看点一}}</span>
  </p>
  <p style="font-size:14px;color:#141413;margin:0;padding:10px 0;border-top:1px solid #E3DFD3;">
    <span style="color:#A34F36;font-weight:700;"><span leaf="">02　</span></span><span leaf="">{{看点二}}</span>
  </p>
  <p style="font-size:14px;color:#141413;margin:0;padding:10px 0;border-top:1px solid #E3DFD3;border-bottom:1px solid #E3DFD3;">
    <span style="color:#A34F36;font-weight:700;"><span leaf="">03　</span></span><span leaf="">{{看点三}}</span>
  </p>
</section>
```

---

## 组件 4 章节标题（✻ 编号 + 衬线标题 + 细线）

> 第一章（紧跟本文看点）`margin-top:24px`，后续 `margin-top:48px`。本文看点底边距固定 36px。英文小标签按章节含义生成。

```html
<section style="margin:48px 12px 22px;">
  <p style="font-size:13px;color:#A34F36;margin:0 0 6px;letter-spacing:2px;font-weight:600;">
    <span leaf="">✻ 01 · {{ENGLISH TAG}}</span>
  </p>
  <h3 style="font-family:'Songti SC','STSong','Noto Serif SC',Georgia,serif;font-size:21px;font-weight:700;color:#141413;margin:0 0 14px;line-height:1.4;">
    <span leaf="">{{中文章节标题}}</span>
  </h3>
  <section style="height:1px;background:#E3DFD3;margin:0;">
    <span leaf=""><br></span>
  </section>
</section>
```

**结语章节变体**：编号行写 `✻ ∞ · EPILOGUE`。

---

## 组件 5 正文段落

> **本主题不跟随 SKILL.md「每段 1–3 处下划线」的默认规则**（作者反馈加粗过多）：全文最多 6 处 7c 标记，只标结论、关键数据和全文主张，其余段落不标。宁少勿多。

**基础段落**：

```html
<p style="margin:0 12px 20px;font-size:15px;line-height:1.85;text-align:justify;color:#3D3D3A;">
  <span leaf="">{{正文}}</span>
</p>
```

**带下划线标记的段落（默认）**：

```html
<p style="margin:0 12px 20px;font-size:15px;line-height:1.85;text-align:justify;color:#3D3D3A;">
  <span leaf="">{{前半句}}</span><span style="border-bottom:2px solid #EBC7B5;font-weight:600;color:#141413;"><span leaf="">{{关键短语}}</span></span><span leaf="">{{后半句}}</span>
</p>
```

---

## 组件 6 子标题（`###`）

```html
<p style="font-family:'Songti SC','STSong','Noto Serif SC',Georgia,serif;font-size:17px;font-weight:700;color:#141413;margin:32px 12px 14px;line-height:1.5;">
  <span style="color:#A34F36;"><span leaf="">✻ </span></span><span leaf="">{{子标题}}</span>
</p>
```

---

## 组件 7 行内标记

### 7a. 加粗

普通加粗（默认）：

```html
<strong style="color:#141413;"><span leaf="">普通加粗</span></strong>
```

陶土加粗（锚点，全文 ≤5 处）：

```html
<strong style="color:#A34F36;"><span leaf="">锚点加粗</span></strong>
```

### 7b. 概念标签（每篇 2~4 个）

```html
<span style="background:#F7E8E0;color:#A34F36;padding:1px 6px;border-radius:4px;font-weight:600;"><span leaf="">概念</span></span>
```

### 7c. 陶土下划线（正文默认标记）

```html
<span style="border-bottom:2px solid #EBC7B5;font-weight:600;color:#141413;"><span leaf="">关键短语</span></span>
```

### 7d. 行内代码

```html
<span style="background:#F0EEE6;color:#141413;padding:1px 6px;border-radius:4px;font-family:Menlo,Consolas,monospace;"><span leaf="">code</span></span>
```

---

## 组件 8 引用与旁注

### 8a. 金句引用（燕麦底 + 陶土竖条，衬线）

```html
<section style="margin:4px 12px 24px;background:#F0EEE6;border-left:3px solid #D97757;border-radius:0 8px 8px 0;padding:16px 20px;">
  <p style="font-family:'Songti SC','STSong','Noto Serif SC',Georgia,serif;font-size:16px;font-weight:700;color:#141413;margin:0;line-height:1.8;">
    <span leaf="">{{金句}}</span>
  </p>
</section>
```

### 8b. 旁注（细边框，轻量补充、个人说明）

```html
<section style="margin:4px 12px 24px;border:1px solid #E3DFD3;border-radius:8px;padding:12px 16px;">
  <p style="font-size:13px;color:#6B6A63;margin:0;line-height:1.8;">
    <span style="color:#A34F36;font-weight:600;"><span leaf="">注　</span></span><span leaf="">{{旁注}}</span>
  </p>
</section>
```

---

## 组件 9 列表

### 9a. 要点列表（陶土圆点 + 正文，每项一个 `<p>`）

```html
<section style="margin:0 12px 22px;">
  <p style="font-size:15px;line-height:1.85;margin:0 0 10px;padding-left:18px;text-indent:-18px;color:#3D3D3A;">
    <span style="color:#A34F36;font-weight:700;"><span leaf="">●　</span></span><span leaf="">{{要点}}</span>
  </p>
</section>
```

（多项时重复内部 `<p>`，最后一项 `margin-bottom:0`。标记放在固定宽度的 inline-block 槽位里，宽度与悬挂缩进相等，续行才能和首行正文对齐。列表项默认不标下划线，计入全文 ≤6 处的配额。）

### 9b. 编号列表

```html
<section style="margin:0 12px 22px;">
  <p style="font-size:15px;line-height:1.85;margin:0 0 10px;padding-left:24px;text-indent:-24px;color:#3D3D3A;">
    <span style="display:inline-block;width:24px;text-indent:0;color:#A34F36;font-weight:700;"><span leaf="">1.</span></span><span leaf="">{{步骤}}</span>
  </p>
</section>
```

---

## 组件 10 图片容器

```html
<section style="margin:8px 12px 6px;background:#FFFFFF;border:1px solid #E3DFD3;border-radius:10px;padding:6px;">
  <section style="border-radius:6px;overflow:hidden;">
    <span leaf=""><img src="图片URL" style="max-width:100%;height:auto;display:block;margin:0 auto;"></span>
  </section>
</section>
<p style="font-size:12px;color:#6B6A63;text-align:center;margin:0 12px 26px;">
  <span leaf="">{{图片说明，无则删掉此 p 并把上方 margin-bottom 改 24px}}</span>
</p>
```

---

## 组件 11 数据卡（两列）

> 只放两项短数字（≤8 个字符）。超过两项、数字较长或有说明文字时，改用纵向单列卡（把内层两个 section 拆成上下两块，去掉 display:flex）。不要拿它替代 Markdown 表格。

```html
<section style="display:flex;margin:4px 12px 24px;">
  <section style="flex:1;min-width:0;background:#F0EEE6;border-radius:10px;padding:16px;margin-right:8px;">
    <p style="font-family:Georgia,serif;font-size:24px;font-weight:700;color:#A34F36;margin:0;line-height:1.2;word-break:break-all;"><span leaf="">{{数字}}</span></p>
    <p style="font-size:12px;color:#6B6A63;margin:6px 0 0;"><span leaf="">{{说明}}</span></p>
  </section>
  <section style="flex:1;min-width:0;background:#F0EEE6;border-radius:10px;padding:16px;">
    <p style="font-family:Georgia,serif;font-size:24px;font-weight:700;color:#A34F36;margin:0;line-height:1.2;word-break:break-all;"><span leaf="">{{数字}}</span></p>
    <p style="font-size:12px;color:#6B6A63;margin:6px 0 0;"><span leaf="">{{说明}}</span></p>
  </section>
</section>
```

---

## 组件 12 END 结尾

```html
<section style="margin:44px 12px 8px;text-align:center;">
  <p style="font-size:16px;color:#D97757;margin:0;letter-spacing:8px;">
    <span leaf="">✻ ✻ ✻</span>
  </p>
</section>
```

---

## 组件 13 尾部作者签名区

```html
<section style="margin:20px 12px 0;padding:16px 0 0;border-top:1px solid #E3DFD3;">
  <p style="font-size:13px;color:#6B6A63;margin:0;line-height:1.8;">
    <span leaf="">我是 </span><span style="color:#141413;font-weight:600;"><span leaf="">{{作者名}}</span></span><span leaf="">，{{一句话简介}}</span>
  </p>
  <p style="font-size:13px;color:#6B6A63;margin:6px 0 0;line-height:1.8;">
    <span leaf="">{{互动引导，默认：如果这篇对你有用，欢迎点赞、在看、转发，我们下篇见。作者不要互动引导时删掉整个 p}}</span>
  </p>
</section>
```

---

## 完整文章模板骨架

1. 组件 1 全局容器开始
2. 组件 2 开头引言卡（有开头引用或可提炼核心判断时）
3. 第一个 `##` 之前的导语段落（组件 5）
4. 组件 3 本文看点（≥3 个章节时）
5. 每个 `##` → 组件 4 章节标题，后接该章正文；`###` → 组件 6
6. 组件 12 END
7. 组件 13 签名区（全文末尾唯一一处；作者没给署名就保留 `{{作者名}}` / `{{一句话简介}}` 占位并提醒替换）
8. 全局容器结束

注意：本主题导语放在看点之前，因为本主题偏随笔叙事，先让读者进入情境再给目录。

---

## 视觉层级

| 层级 | 样式 | 频率 |
|------|------|------|
| 锚点层 | 陶土加粗 7a、金句引用 8a | 全文 ≤5 处 |
| 标记层 | 陶土下划线 7c（加粗+下划线）、概念标签 7b | 全文 ≤6 处 |
| 容器层 | 旁注 8b、列表 9、数据卡 11、图片 10 | 按需 |

---

## 文章类型 → 组件组合配方

| 文章类型 | 核心组件组合 | 点缀组件 |
|---|---|---|
| 观点/技术随笔 | 正文 5 + 子标题 6 + 金句 8a | 旁注 8b、要点列表 9a |
| 读书/文章笔记 | 引言卡 2 + 子标题 6（按文章分节）+ 正文 5 | 概念标签 7b、旁注 8b |
| 案例复盘 | 章节 4 + 编号列表 9b + 数据卡 11 | 金句 8a、图片 10 |
| 教程 | 编号列表 9b + 代码块（通用库 1b，竖条换 #D97757） | 旁注 8b |
| 数据报告 | 数据卡 11 + 图片 10 + 正文 5 | 概念标签 7b |

---

## Markdown → Claude 陶土 映射规则

| Markdown 元素 | 对应组件 | 说明 |
|---|---|---|
| `# 标题` | 不使用 | 标题在平台设置 |
| 开头 `> 引言` | 组件 2 | |
| `## 章节` | 组件 4 | ✻ 01/02…，末章结语用 ∞ |
| `### 子标题` | 组件 6 | |
| 普通段落 | 组件 5 | 默认不标；全文挑 ≤6 处结论用 7c |
| `**加粗**` | 7a 普通加粗 / 锚点陶土加粗 | |
| `==高亮==` | 7b 概念标签 | |
| `<u>文字</u>` / `++文字++` | 7c 陶土下划线 | |
| `~~文字~~` | `text-decoration:line-through;color:#6B6A63` | 被否定的旧说法 |
| `---` 分割线 | 组件 4 里的细线 section 单独使用（margin:32px 12px） | |
| Markdown 表格 | 保留所有字段：`<table>` 每格内联 `padding:8px 10px;border-bottom:1px solid #E3DFD3;font-size:14px;`，表头 `color:#6B6A63`；超过 4 列时拆成每行一张纵向卡 | 不要压成两列数据卡 |
| `![](x.gif)` | 通用库 2b GIF | |
| `` `code` `` | 7d | |
| `> 引用`（金句） | 8a | |
| `> 引用`（旁注） | 8b | |
| `- 列表` | 9a | |
| `1. 列表` | 9b | |
| `![说明](url)` | 组件 10 | 无说明删说明行 |
| ` ``` 代码 ``` ` | 通用库 1b 浅色代码块 | 竖条换 #D97757 |
| 数据对比 | 组件 11 | |
