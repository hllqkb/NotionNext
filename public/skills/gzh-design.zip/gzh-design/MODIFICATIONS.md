# 修改说明

本目录基于 [isjiamu/gzh-design-skill](https://github.com/isjiamu/gzh-design-skill) 提交 750a50d，按 AGPL-3.0 再分发，许可证见 LICENSE。

hllqkb 在 2026-10 做的修改：

- 新增 `references/theme-claude-clay.md`（Claude 陶土主题）
- `references/theme-index.md` 增加该主题一行
