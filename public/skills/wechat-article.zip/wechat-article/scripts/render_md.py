#!/usr/bin/env python3
"""Render a WeChat article Markdown file with the gzh-design "Claude 陶土" theme.

Supported Markdown: `# 标题`（忽略）, `## 章节`, `### 小节`, 段落, `1. ` 编号列表,
`- ` 圆点列表, `**加粗**`（全文 ≤6 处）, `` `code` ``, `---`（忽略）。

Usage:
    render_md.py article.md out.html --config config.json

config.json:
{
  "tags": {"章节标题": "ENGLISH TAG", ...},          # 每个 ## 的英文小标签；末章可写 "∞|EPILOGUE"
  "highlights": ["看点一", "看点二", "看点三"],       # 可选，本文看点（放在导语之后）
  "lead_quote": {"text": "...", "source": "..."},    # 可选，开头引言卡
  "images": [{"after": "段落开头文字", "src": "url", "caption": "可选图注"}], # 图片插在以该文字开头的段落之后
  "signature": "我是 hllqkb，……"                      # 结尾签名
}
"""
import argparse
import html
import json
import re
from pathlib import Path

SERIF = "'Songti SC','STSong','Noto Serif SC',Georgia,serif"
SANS = "-apple-system,BlinkMacSystemFont,'PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif"
BOLD = "border-bottom:2px solid #EBC7B5;font-weight:600;color:#141413;"
CODE = "background:#F0EEE6;color:#141413;padding:1px 6px;border-radius:4px;font-family:Menlo,Consolas,monospace;"
P_STYLE = "margin:0 12px 20px;font-size:15px;line-height:1.85;text-align:justify;color:#3D3D3A;"


def leaf(text: str) -> str:
    return f'<span leaf="">{html.escape(text, quote=False)}</span>'


def inline(text: str) -> str:
    out = []
    for tok in re.split(r"(\*\*[^*]+\*\*|`[^`]+`)", text):
        if not tok:
            continue
        if tok.startswith("**"):
            out.append(f'<span style="{BOLD}">{leaf(tok[2:-2])}</span>')
        elif tok.startswith("`"):
            out.append(f'<span style="{CODE}">{leaf(tok[1:-1])}</span>')
        else:
            out.append(leaf(tok))
    return "".join(out)


def para(text: str) -> str:
    return f'<p style="{P_STYLE}">{inline(text)}</p>'


def chapter(num: str, tag: str, title: str, first: bool) -> str:
    mt = 24 if first else 48
    return (f'<section style="margin:{mt}px 12px 22px;">'
            f'<p style="font-size:13px;color:#A34F36;margin:0 0 6px;letter-spacing:2px;font-weight:600;">{leaf(f"✻ {num} · {tag}")}</p>'
            f'<h3 style="font-family:{SERIF};font-size:21px;font-weight:700;color:#141413;margin:0 0 14px;line-height:1.4;">{leaf(title)}</h3>'
            f'<section style="height:1px;background:#E3DFD3;margin:0;"><span leaf=""><br></span></section></section>')


def sub(title: str) -> str:
    return (f'<p style="font-family:{SERIF};font-size:17px;font-weight:700;color:#141413;margin:32px 12px 14px;line-height:1.5;">'
            f'<span style="color:#D97757;">{leaf("✻ ")}</span>{leaf(title)}</p>')


def items(lines: list[str], ordered: bool) -> str:
    ps = []
    for i, t in enumerate(lines):
        mb = 0 if i == len(lines) - 1 else 10
        if ordered:
            mark = f'<span style="display:inline-block;width:24px;text-indent:0;color:#A34F36;font-weight:700;">{leaf(f"{i + 1}.")}</span>'
            pad = 24
        else:
            mark = f'<span style="display:inline-block;width:20px;text-indent:0;color:#D97757;">{leaf("●")}</span>'
            pad = 20
        ps.append(f'<p style="font-size:15px;line-height:1.85;margin:0 0 {mb}px;padding-left:{pad}px;text-indent:-{pad}px;color:#3D3D3A;">{mark}{inline(t)}</p>')
    return f'<section style="margin:0 12px 22px;">{"".join(ps)}</section>'


def image(src: str, caption: str = "") -> str:
    mb = 6 if caption else 24
    out = (f'<section style="margin:8px 12px {mb}px;border:1px solid #ECE9E0;border-radius:8px;overflow:hidden;">'
           f'<span leaf=""><img src="{html.escape(src)}" style="max-width:100%;height:auto;display:block;margin:0 auto;"></span></section>')
    if caption:
        out += f'<p style="font-size:12px;color:#6B6A63;text-align:center;margin:0 12px 24px;">{leaf(caption)}</p>'
    return out


def render(md: str, cfg: dict) -> str:
    lines = md.strip().splitlines()
    blocks: list[tuple[str, object]] = []
    buf: list[str] = []
    kind = None

    def flush():
        nonlocal buf, kind
        if buf:
            blocks.append((kind, buf))
        buf, kind = [], None

    for raw in lines:
        s = raw.strip()
        if not s or s == "---" or s.startswith("# "):
            flush()
            continue
        if s.startswith("## "):
            flush(); blocks.append(("h2", s[3:])); continue
        if s.startswith("### "):
            flush(); blocks.append(("h3", s[4:])); continue
        m = re.match(r"^(\d+)\.\s+(.*)$", s)
        if m:
            if kind != "ol": flush(); kind = "ol"
            buf.append(m.group(2)); continue
        if s.startswith("- "):
            if kind != "ul": flush(); kind = "ul"
            buf.append(s[2:]); continue
        flush(); blocks.append(("p", s))
    flush()

    tags = cfg.get("tags", {})
    imgs = list(cfg.get("images", []))
    out = [f'<section style="max-width:677px;margin:0 auto;font-family:{SANS};color:#3D3D3A;line-height:1.85;letter-spacing:0.4px;padding:8px 0 24px;overflow-x:hidden;">']
    lq = cfg.get("lead_quote")
    if lq:
        out.append(f'<section style="margin:16px 12px 32px;background:#F0EEE6;border-left:3px solid #D97757;border-radius:0 10px 10px 0;padding:20px 22px;">'
                   f'<p style="font-size:13px;color:#D97757;margin:0 0 10px;letter-spacing:2px;">{leaf("✻")}</p>'
                   f'<p style="font-family:{SERIF};font-size:17px;font-weight:700;color:#141413;margin:0;line-height:1.75;">{leaf(lq["text"])}</p>'
                   + (f'<p style="text-align:right;font-size:12px;color:#6B6A63;margin:12px 0 0;">{leaf("—— " + lq["source"])}</p>' if lq.get("source") else "")
                   + "</section>")
    chap = 0
    highlights_done = not cfg.get("highlights")
    for kind, val in blocks:
        if kind == "h2":
            if not highlights_done:
                kp = "".join(
                    f'<p style="font-size:14px;color:#141413;margin:0;padding:10px 0;border-top:1px solid #E3DFD3;{"border-bottom:1px solid #E3DFD3;" if i == len(cfg["highlights"]) - 1 else ""}">'
                    f'<span style="display:inline-block;width:30px;color:#A34F36;font-weight:700;">{leaf(f"{i + 1:02d}")}</span>{leaf(t)}</p>'
                    for i, t in enumerate(cfg["highlights"]))
                out.append(f'<section style="margin:8px 12px 36px;"><p style="font-size:12px;color:#6B6A63;margin:0 0 12px;letter-spacing:2px;">{leaf("本文看点")}</p>{kp}</section>')
                highlights_done = True
            chap += 1
            tag = tags.get(val, "SECTION")
            num = f"{chap:02d}"
            if "|" in tag:
                num, tag = tag.split("|", 1)
            out.append(chapter(num, tag, val, first=(chap == 1)))
        elif kind == "h3":
            out.append(sub(val))
        elif kind in ("ol", "ul"):
            out.append(items(val, kind == "ol"))
        else:
            out.append(para(val))
            for im in [x for x in imgs if val.startswith(x["after"])]:
                out.append(image(im["src"], im.get("caption", "")))
                imgs.remove(im)
    if imgs:
        raise SystemExit(f"images not placed: {[x['after'] for x in imgs]}")
    out.append(f'<section style="margin:44px 12px 8px;text-align:center;"><p style="font-size:16px;color:#D97757;margin:0;letter-spacing:8px;">{leaf("✻ ✻ ✻")}</p></section>')
    if cfg.get("signature"):
        sig = cfg["signature"]
        name = "hllqkb"
        if name in sig:
            a, b = sig.split(name, 1)
            body = leaf(a) + f'<span style="color:#141413;font-weight:600;">{leaf(name)}</span>' + leaf(b)
        else:
            body = leaf(sig)
        out.append(f'<section style="margin:20px 12px 0;padding:16px 0 0;border-top:1px solid #E3DFD3;"><p style="font-size:13px;color:#6B6A63;margin:0;line-height:1.8;">{body}</p></section>')
    out.append("</section>")
    return "\n".join(out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("md", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--config", type=Path, required=True)
    a = ap.parse_args()
    html_out = render(a.md.read_text(encoding="utf-8"), json.loads(a.config.read_text(encoding="utf-8")))
    n_bold = html_out.count("border-bottom:2px solid #EBC7B5")
    if n_bold > 6:
        raise SystemExit(f"too many highlights: {n_bold} > 6")
    a.out.write_text(html_out, encoding="utf-8")
    print(f"wrote {a.out} (highlights={n_bold})")


if __name__ == "__main__":
    main()
